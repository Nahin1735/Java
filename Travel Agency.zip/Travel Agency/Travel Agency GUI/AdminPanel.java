import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.lang.*;

public class AdminPanel extends JFrame {

    private Container c;
    private ImageIcon icon, logo;
    private JLabel label1, imgLabel;
    private Font f1, f2, f3, f4, f5, f6;
    private JTextField tf1;
    private JScrollPane scroll;
    private JTable table;
    private DefaultTableModel model;
    private JButton btn1, btn2, btn3, btn4, btn5, btn6, nBtn;
    private JPasswordField tf2;
    private Cursor cursor;

    private String[] column = { "User Name", "Password", "Email" };
    private String[] rows = new String[4];

    AdminPanel() {
        // Frame Layout
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Travel Agency");
        this.setSize(700, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#F2F2F2"));

        // Icon
        icon = new ImageIcon(getClass().getResource("/images/Icon.png"));
        this.setIconImage(icon.getImage());

        // Fonts
        f1 = new Font("Segoe UI Black", Font.BOLD, 60);
        f2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        f3 = new Font("Segoe UI", Font.PLAIN, 20);
        f4 = new Font("Segoe UI", Font.PLAIN, 30);
        f5 = new Font("Segoe UI", Font.PLAIN, 22);
        f6 = new Font("Segoe UI", Font.PLAIN, 25);

        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);

        // Title
        label1 = new JLabel();
        label1.setText("Admin Panel");
        label1.setBounds(155, 10, 400, 100);
        label1.setFont(f1);
        c.add(label1);

        // JButtons

        // btn1 = new JButton("Delete");
        // btn1.setBounds(53, 419, 180, 50);
        // btn1.setFont(f2);
        // btn1.setCursor(cursor);
        // btn1.setForeground(Color.WHITE);
        // btn1.setBackground(Color.decode("#C00000"));
        // c.add(btn1);

        // btn2 = new JButton("Modify");
        // btn2.setBounds(252, 419, 180, 50);
        // btn2.setFont(f2);
        // btn2.setCursor(cursor);
        // btn2.setForeground(Color.WHITE);
        // btn2.setBackground(Color.decode("#2E75B6"));
        // c.add(btn2);

        // btn3 = new JButton("Add");
        // btn3.setBounds(451, 419, 180, 50);
        // btn3.setFont(f2);
        // btn3.setCursor(cursor);
        // btn3.setForeground(Color.WHITE);
        // btn3.setBackground(Color.decode("#2E75B6"));
        // c.add(btn3);
        
        btn4 = new JButton("Exit");
        btn4.setBounds(53, 480, 180, 50);
        btn4.setFont(f2);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#C00000"));
        c.add(btn4);

        btn5 = new JButton("Back");
        btn5.setBounds(252, 480, 180, 50);
        btn5.setFont(f2);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#2E75B6"));
        c.add(btn5);

        btn6 = new JButton("Refresh");
        btn6.setBounds(451, 480, 180, 50);
        btn6.setFont(f2);
        btn6.setCursor(cursor);
        btn6.setForeground(Color.WHITE);
        btn6.setBackground(Color.decode("#2E75B6"));
        c.add(btn6);

        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        // JTable Layout
        table = new JTable();
        model = new DefaultTableModel();
        model.setColumnIdentifiers(column);

        table.setModel(model);
        table.setFont(f3);
        table.setSelectionBackground(Color.GREEN);
        table.setBackground(Color.WHITE);
        table.setRowHeight(30);
        table.getColumnModel().getColumn(0).setPreferredWidth(130);
        table.getColumnModel().getColumn(1).setPreferredWidth(130);
        table.getColumnModel().getColumn(2).setPreferredWidth(350);
        table.disable();

        scroll = new JScrollPane(table);
        scroll.setBounds(53, 96, 578, 350);
        scroll.setBackground(Color.WHITE);
        c.add(scroll);

        // To input data in the table
        try {

            BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt"));
            int totalLines = 0;
            while (reader.readLine() != null)
                totalLines++;
            reader.close();

            for (int i = 0; i < totalLines; i++) {
                String line = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get(i);
                String x = line.substring(0, 4);
                if (x.equals("User")) {
                    String userName = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get(i);
                    String userNameGet = userName.substring(12);
                    String password = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get((i + 1));
                    String passwordGet = password.substring(11);
                    String email = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get((i + 2));
                    String emailGet = email.substring(8);

                    rows[0] = userNameGet;
                    rows[1] = passwordGet;
                    rows[2] = emailGet;
                    model.addRow(rows);
                }
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }

        // // Delete Button
        // btn1.addActionListener(new ActionListener() {
        //     public void actionPerformed(ActionEvent ae) {
                
        //     }
        // });

        // // Modify Button
        // btn2.addActionListener(new ActionListener() {
        //     public void actionPerformed(ActionEvent ae) {
                
        //     }
        // });

        // // Add Button
        // btn3.addActionListener(new ActionListener() {
        //     public void actionPerformed(ActionEvent ae) {
                
        //     }
        // });

        // Exit Button
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });

        // Back Button
        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Home frame = new Home();
                frame.setVisible(true);

            }
        });

        // Refresh Button
        btn6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                AdminPanel frame = new AdminPanel();
                frame.setVisible(true);

            }
        });
    }

    public static void main(String[] args) {

        AdminPanel frame = new AdminPanel();
        frame.setVisible(true);
    }
}
