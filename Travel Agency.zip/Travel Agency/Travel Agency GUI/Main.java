import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Main {

    public static void main(String[] args) {

        Welcome frame = new Welcome();
        frame.setVisible(true);
    }
}
